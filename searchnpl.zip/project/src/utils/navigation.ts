import { NavigationOptions } from '../types/navigation';

export function navigateToUrl({ url, target = '_self' }: NavigationOptions): void {
  // For external URLs, always use _blank target with security attributes
  if (url.startsWith('http')) {
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    link.click();
    return;
  }
  
  // For internal URLs, use regular navigation
  window.location.assign(url);
}