import { SearchEngine, SearchOptions } from '../types/search';
import { navigateToUrl } from './navigation';

const SEARCH_ENGINES: Record<SearchEngine, string> = {
  GOOGLE: 'https://www.google.com/search',
  BING: 'https://www.bing.com/search',
  DUCKDUCKGO: 'https://duckduckgo.com/'
};

export function performSearch({ query, engine = 'GOOGLE', feelingLucky = false }: SearchOptions): void {
  if (!query.trim()) return;

  try {
    const searchUrl = new URL(SEARCH_ENGINES[engine]);
    searchUrl.searchParams.append('q', encodeURIComponent(query.trim()));
    
    if (feelingLucky && engine === 'GOOGLE') {
      searchUrl.searchParams.append('btnI', '1');
    }

    navigateToUrl({ 
      url: searchUrl.toString(),
      target: '_blank'
    });
  } catch (error) {
    console.error('Failed to perform search:', error);
  }
}