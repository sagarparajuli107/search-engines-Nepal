export interface NavigationOptions {
  url: string;
  target?: '_self' | '_blank';
}