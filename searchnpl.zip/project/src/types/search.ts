export type SearchEngine = 'GOOGLE' | 'BING' | 'DUCKDUCKGO';

export interface SearchOptions {
  query: string;
  engine?: SearchEngine;
  feelingLucky?: boolean;
}

export interface SearchState {
  query: string;
  selectedEngine: SearchEngine;
}