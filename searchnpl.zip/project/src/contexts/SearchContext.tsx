import React, { createContext, useContext, useState, ReactNode } from 'react';
import { SearchEngine, SearchOptions, SearchState } from '../types/search';
import { performSearch } from '../utils/search';

interface SearchContextType extends SearchState {
  setQuery: (query: string) => void;
  setSelectedEngine: (engine: SearchEngine) => void;
  handleSearch: (options: { feelingLucky?: boolean }) => void;
}

const SearchContext = createContext<SearchContextType | undefined>(undefined);

export function SearchProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<SearchState>({
    query: '',
    selectedEngine: 'GOOGLE'
  });

  const handleSearch = ({ feelingLucky = false }) => {
    performSearch({ 
      query: state.query, 
      engine: state.selectedEngine, 
      feelingLucky 
    });
  };

  return (
    <SearchContext.Provider value={{
      ...state,
      setQuery: (query) => setState(prev => ({ ...prev, query })),
      setSelectedEngine: (engine) => setState(prev => ({ ...prev, engine })),
      handleSearch
    }}>
      {children}
    </SearchContext.Provider>
  );
}

export function useSearch() {
  const context = useContext(SearchContext);
  if (context === undefined) {
    throw new Error('useSearch must be used within a SearchProvider');
  }
  return context;
}