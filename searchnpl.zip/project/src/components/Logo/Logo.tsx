import React from 'react';
import { Building2 } from 'lucide-react';

export function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="relative">
        <Building2 size={48} className="text-red-500" strokeWidth={2} />
        <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-blue-500 rounded-full border-2 border-white" />
      </div>
      <div className="flex flex-col">
        <h1 className="text-4xl font-bold text-gray-800">SagarGrup</h1>
        <span className="text-sm text-gray-500">Search Engine</span>
      </div>
    </div>
  );
}