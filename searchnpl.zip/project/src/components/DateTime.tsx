import React, { useState, useEffect } from 'react';
import { Clock, MapPin } from 'lucide-react';

export function DateTime() {
  const [dateTime, setDateTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDateTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-col items-center gap-2 text-gray-600">
      <div className="flex items-center gap-2">
        <Clock size={20} />
        <span>{dateTime.toLocaleTimeString('en-US')}</span>
      </div>
      <div className="flex items-center gap-2">
        <MapPin size={20} />
        <span>Kathmandu, Nepal</span>
      </div>
      <div>
        {dateTime.toLocaleDateString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric'
        })}
      </div>
    </div>
  );
}