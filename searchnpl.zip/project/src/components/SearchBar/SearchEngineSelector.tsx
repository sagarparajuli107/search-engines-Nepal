import React from 'react';
import { useSearch } from '../../contexts/SearchContext';
import { SearchEngine } from '../../types/search';

const SEARCH_ENGINE_CONFIG = [
  { value: 'GOOGLE' as const, label: 'Google', icon: '🔍' },
  { value: 'BING' as const, label: 'Bing', icon: '🔎' },
  { value: 'DUCKDUCKGO' as const, label: 'DuckDuckGo', icon: '🦆' }
] as const;

export function SearchEngineSelector() {
  const { selectedEngine, setSelectedEngine } = useSearch();

  return (
    <div className="flex gap-2">
      {SEARCH_ENGINE_CONFIG.map(engine => (
        <button
          key={engine.value}
          onClick={() => setSelectedEngine(engine.value)}
          className={`px-4 py-2 rounded-full transition-colors ${
            selectedEngine === engine.value
              ? 'bg-red-500 text-white'
              : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
          }`}
        >
          <span className="mr-2">{engine.icon}</span>
          {engine.label}
        </button>
      ))}
    </div>
  );
}