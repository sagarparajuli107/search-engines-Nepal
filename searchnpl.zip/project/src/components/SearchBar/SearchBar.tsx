import React, { FormEvent } from 'react';
import { SearchInput } from './SearchInput';
import { SearchButtons } from './SearchButtons';
import { SearchEngineSelector } from './SearchEngineSelector';
import { useSearch } from '../../contexts/SearchContext';

export function SearchBar() {
  const { handleSearch } = useSearch();

  const onSubmit = (e: FormEvent, feelingLucky = false) => {
    e.preventDefault();
    handleSearch({ feelingLucky });
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-2xl">
      <SearchEngineSelector />
      <form onSubmit={(e) => onSubmit(e)} className="w-full">
        <SearchInput />
      </form>
      <SearchButtons 
        onSearch={(e) => onSubmit(e)}
        onLucky={(e) => onSubmit(e, true)}
      />
    </div>
  );
}