import React from 'react';
import { Search } from 'lucide-react';
import { useSearch } from '../../contexts/SearchContext';

export function SearchInput() {
  const { query, setQuery } = useSearch();

  return (
    <div className="relative flex items-center">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="w-full px-6 py-3 rounded-full border border-gray-300 focus:outline-none focus:border-red-500 focus:ring-2 focus:ring-red-200 text-lg"
        placeholder="Search anything..."
        autoFocus
        aria-label="Search input"
      />
      <button
        type="submit"
        className="absolute right-3 p-2 text-gray-600 hover:text-red-500"
        aria-label="Submit search"
      >
        <Search size={24} />
      </button>
    </div>
  );
}