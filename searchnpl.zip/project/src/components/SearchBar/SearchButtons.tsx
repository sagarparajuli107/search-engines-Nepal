import React, { FormEvent } from 'react';

interface SearchButtonsProps {
  onSearch: (e: FormEvent) => void;
  onLucky: (e: FormEvent) => void;
}

export function SearchButtons({ onSearch, onLucky }: SearchButtonsProps) {
  return (
    <div className="flex gap-4">
      <button 
        onClick={onSearch}
        className="px-6 py-2 bg-gray-50 text-gray-700 rounded hover:shadow-md transition-shadow"
      >
        Search
      </button>
      <button 
        onClick={onLucky}
        className="px-6 py-2 bg-gray-50 text-gray-700 rounded hover:shadow-md transition-shadow"
      >
        I'm Feeling Lucky
      </button>
    </div>
  );
}