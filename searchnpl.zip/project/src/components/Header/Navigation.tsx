import React from 'react';

export function Navigation() {
  return (
    <nav className="flex gap-4 text-gray-600">
      <a href="#" className="hover:text-red-500">Gmail</a>
      <a href="#" className="hover:text-red-500">Images</a>
    </nav>
  );
}