import React from 'react';

export function Footer() {
  return (
    <footer className="fixed bottom-0 w-full bg-gray-50 text-sm text-gray-600">
      <div className="border-t border-gray-200">
        <div className="px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex gap-6">
              <a href="#" className="hover:text-red-500">About</a>
              <a href="#" className="hover:text-red-500">Advertising</a>
              <a href="#" className="hover:text-red-500">Business</a>
            </div>
            <div className="flex gap-6">
              <a href="#" className="hover:text-red-500">Privacy</a>
              <a href="#" className="hover:text-red-500">Terms</a>
              <a href="#" className="hover:text-red-500">Settings</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}