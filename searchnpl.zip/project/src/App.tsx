import React from 'react';
import { Navigation } from './components/Header/Navigation';
import { Logo } from './components/Logo/Logo';
import { SearchBar } from './components/SearchBar/SearchBar';
import { DateTime } from './components/DateTime';
import { Footer } from './components/Footer/Footer';
import { SearchProvider } from './contexts/SearchContext';

function App() {
  return (
    <SearchProvider>
      <div className="min-h-screen bg-gradient-to-b from-white to-gray-100">
        <header className="p-4 flex justify-end">
          <Navigation />
        </header>

        <main className="flex flex-col items-center justify-center px-4 space-y-8" style={{ minHeight: 'calc(100vh - 180px)' }}>
          <div className="flex flex-col items-center gap-6">
            <Logo />
            <DateTime />
            <SearchBar />
          </div>
        </main>

        <Footer />
      </div>
    </SearchProvider>
  );
}

export default App;